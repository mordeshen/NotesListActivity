package com.e.occanotestsidep.utils

interface StateEvent {
    fun errorInfo():String
}