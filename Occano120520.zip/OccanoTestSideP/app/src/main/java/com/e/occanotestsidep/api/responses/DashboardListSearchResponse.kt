package com.e.occanotestsidep.api.responses

import com.e.occano.api.main.responses.StatusSearchResponse
import com.e.occanotestsidep.ui.models.Status
import com.e.occanotestsidep.ui.models.Cylinder
import com.e.occanotestsidep.ui.models.DashMetaData
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class DashboardListSearchResponse(

    @SerializedName("cylinders")
    @Expose
    var cylinders: List<CylinderSearchResponse>,

    @SerializedName("status")
    @Expose
    var status: List<StatusSearchResponse>,

    @SerializedName("metadata")
    @Expose
    var metaData: MetaDataSearchResponse,

    @SerializedName("count_of_cylinders")
    @Expose
    var count_of_cylinders: Int,

    @SerializedName("time_passed")
    @Expose
    var time_passed: Long


) {

    fun cylToList(): List<Cylinder>{
        val cylsList: ArrayList<Cylinder> = ArrayList()
        for(cylinderResponse in cylinders){
            cylsList.add(
                cylinderResponse.toCylinder()
            )
        }
        println("cyl to list")
        return cylsList
    }

    fun statusToList(): List<Status>{
        val statusList: ArrayList<Status> = ArrayList()
        for(statusResponse in status){
            statusList.add(
                statusResponse.toStatus()
            )
        }
        println("status to list")
        return statusList
    }

    fun metaToMetaData(): DashMetaData {
        return metaData.toMetaData()
    }

    override fun toString(): String {
        return "DashboardListSearchResponse(cylinders=$cylinders, status=$status, metaData=$metaData, count_of_cylinders=$count_of_cylinders, time_passed=$time_passed)"
    }


}