package com.e.occanotestsidep.ui.models

data class GaugeApiResponse(
    var value: Float = 0.0f,
    var standard : Float = 0.0f,
    var average: Float = 0.0f
) {
    override fun toString(): String {
        return "GaugeApiResponse(value=$value, standard=$standard, average=$average)"
    }
}