package com.e.occanotestsidep.ui.main.dashboard


import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TabHost
import android.widget.TextView
import androidx.core.graphics.drawable.toDrawable
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2

import com.e.occanotestsidep.R
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

/**
 * A simple [Fragment] subclass.
 */
class SubDadhboardContainer : Fragment() ,TabLayout.OnTabSelectedListener{

    private lateinit var sabaDushCollectionAdapter: SabaDushCollectionAdapter
    private lateinit var viewPager: ViewPager2



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_sub_dadhboard_container, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        sabaDushCollectionAdapter = SabaDushCollectionAdapter(this)
        viewPager = view.findViewById(R.id.pager)
//        viewPager.adapter = sabaDushCollectionAdapter
//        viewPager.isUserInputEnabled = false
        val tabLayout = view.findViewById<TabLayout>(R.id.tab_layout)

        with(tabLayout){
            addTab(tabLayout.newTab().setText("Main").setIcon(R.drawable.ic_report_black_24dp),0,true)
            addTab(tabLayout.newTab().setText("Cylinders").setIcon(R.drawable.ic_filter_center_focus_black_24dp),1)
            addTab(tabLayout.newTab().setText("Dashboard").setIcon(R.drawable.ic_dashboard_black_24dp),2)
            addTab(tabLayout.newTab().setText("Alerts").setIcon(R.drawable.ic_assignment_black_24dp),3)
            addTab(tabLayout.newTab().setText("Archive").setIcon(R.drawable.ic_history_black_24dp),4)
            addTab(tabLayout.newTab().setText("Report").setIcon(R.drawable.ic_report_problem_black_24dp),5)
            addTab(tabLayout.newTab().setText("Graphs").setIcon(R.drawable.ic_trending_up_black_24dp),6)
        }

        tabLayout.addOnTabSelectedListener(this)

//        TabLayoutMediator(
//            tabLayout
//            TabLayoutMediator.TabConfigurationStrategy { tab, position ->
//
//                when(position){
//                    0 -> {
//                        //main dash
//                        tab.text = "Main"
//                        tab.setIcon(R.drawable.ic_report_black_24dp)
//                    }
//                    1->{
//                        //cylinders
//                        tab.text = "Cylinders"
//                        tab.setIcon(R.drawable.ic_filter_center_focus_black_24dp)
//                    }
//                    2->{
//                        //dash
//                        tab.text = "Dashboard"
//                        tab.setIcon(R.drawable.ic_dashboard_black_24dp)
//                    }
//                    3 -> {
//                        //status
//                        tab.text = "Status"
//                        tab.setIcon(R.drawable.ic_assignment_black_24dp)
//                    }
//                    4 -> {
//                        tab.text = "History"
//                        tab.setIcon(R.drawable.ic_history_black_24dp)
//                    }
//                    5 -> {
//                        tab.text = "Report"
//                        tab.setIcon(R.drawable.ic_report_problem_black_24dp)
//                    }
//                    6 -> {
//                        tab.text = "Graphs"
//                        tab.setIcon(R.drawable.ic_trending_up_black_24dp)
//                    }
//                }
//            }).attach()
    }

    override fun onTabReselected(tab: TabLayout.Tab?) {
    }

    override fun onTabUnselected(tab: TabLayout.Tab?) {

    }

    override fun onTabSelected(tab: TabLayout.Tab?) {


//        viewPager.currentItem = tab!!.position
        var fragment: Fragment? = null
        fragment = when(tab?.position){

            0 -> {
                DashboardMainFragment.newInstance("","")
            }
            1 -> {
                CylindersFragment.newInstance(1)
            }
            2 -> {
                DashFragment.newInstance(2)
            }
            3 -> {
                AlertFragment.newInstance(3)
            }
            4 -> {
                ArchivedAlertFragment.newInstance(4)
            }
            5 -> {
                CalibrationFragment()
            }
            6 -> {
                GraphsFragment()
            }
            else -> {
                GraphsFragment()
            }

        }
    }

}





