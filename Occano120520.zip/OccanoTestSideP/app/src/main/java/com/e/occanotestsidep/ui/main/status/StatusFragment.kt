package com.e.occanotestsidep.ui.main.status

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.e.occanosidetest.utils.TopSpacingItemDecoration
import com.e.occanotestsidep.R
import com.e.occanotestsidep.persistence.AppDBK
import com.e.occanotestsidep.ui.main.DashboardStateEvent
import com.e.occanotestsidep.ui.main.DataStateListener
import com.e.occanotestsidep.ui.main.MainViewModel
import com.e.occanotestsidep.ui.models.Status
import kotlinx.android.synthetic.main.fragment_status.*
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StatusFragment :Fragment(), NewStatusAdapter.Interaction, View.OnClickListener {

    private val TAG: String = "StatusFragment"

    lateinit var viewModel: MainViewModel
    lateinit var dataStateListener: DataStateListener
//    lateinit var mStatusRepository: StatusRepository

    var statusesListFromApi = ArrayList<Status>()
    var statusesListFromCache = ArrayList<Status>()
    private var statusesListForRv:MutableList<Status> = ArrayList()
    lateinit var statusNewRVAdapter: NewStatusAdapter
    private lateinit var dbk: AppDBK


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_status,container,false)
    }
    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.e(TAG,"onAttach")
        try {
            dataStateListener = context as DataStateListener
        }catch (e: ClassCastException){
            println("DEBUG: $context must implement DataStateListener ")
        }
    }

    override fun onResume() {
        super.onResume()
        Log.e(TAG,"on resume")
        setUI()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        mStatusRepository = StatusRepository(context)
        Log.e(TAG,"onViewCreated")
        setUI()


    }

    private fun setUI() {
        dbk = AppDBK(requireContext())
        viewModel = activity?.run {
            ViewModelProvider(this).get(MainViewModel::class.java)
        }?:throw Exception("Invalid activity")
        triggerGetStatusesEvent()
        setListeners()
        subscribeObservers()
        initNewRv()
    }

    private fun subscribeObservers(){
        viewModel.dataState.observe(viewLifecycleOwner, Observer { dataState ->

            println("Debug: DataState: ${dataState} ")

            //handle loading and message
            dataStateListener.onDataStateChange(dataState)

            dataState.data?.let {
                it.getContentIfNotHandled()?.statuses?.let {
                    viewModel.setStatusesData(it)
                }
            }

        })

        viewModel.viewState.observe(viewLifecycleOwner, Observer { viewState ->

            viewState.statuses.let {
                println("DEBUG: Setting statuses for rv: ${it}")
                it?.let {
                    prepareStatusList(it)
                }
            }
        })
    }

    fun prepareStatusList(it: List<Status>){

        statusesListFromApi.addAll(it)
        GlobalScope.launch {

            val list = (dbk.getStatusDao()?.getAllStatuses()!!.toMutableList())
            Log.e("from cache ${TAG}",dbk.getStatusDao()?.getAllStatuses()!!.toMutableList().toString())

            withContext(Main){
                statusesListForRv.addAll(list)
                prepareSubList()
                statusNewRVAdapter.submitList(statusesListForRv)
            }

            for (i in statusesListForRv) {
                dbk.getStatusDao()?.deleteStatus(i)
                dbk.getStatusDao()?.insertStatus(i)
            }

            Log.e("second from cache ${TAG}",dbk.getStatusDao()?.getAllStatuses()!!.toMutableList().toString())
            Log.e("statusesListForRv ${TAG}",statusesListForRv.toString())

        }
    }

    fun prepareSubList(){
        for (i in statusesListForRv){
            if (!i.kindOfAcknowledge){
                for (j in statusesListFromApi){
                    if (i.statusId == j.statusId){
                        statusesListFromApi.remove(j)
                    }
                }
            }
        }
        statusesListForRv.union(statusesListFromApi)
        Log.e("statusesListForRv ${TAG}",statusesListForRv.toString())
        statusNewRVAdapter.notifyDataSetChanged()
    }

    private fun triggerGetStatusesEvent() {
        viewModel.setStateEvent(DashboardStateEvent.GetCylinders())
    }

    private fun setListeners() {
        view?.findViewById<ImageButton>(R.id.btn_status_to_dashboard)?.setOnClickListener(this)
        view?.findViewById<ImageButton>(R.id.btn_status_to_archive)?.setOnClickListener(this)
        view?.findViewById<ImageButton>(R.id.btn_status_current)?.setOnClickListener(this)
    }

//    private fun initFakeRvList() {
//        for (i in 1..20){
//            statusesList.add(Status(i,1,"Main Title", "sub title", "subTite","sub moria contenta sub more content sub moria contenta sub more content",
//                1,true, "(Utility.getCurrentTimeStamp().plus(i)).toString())"))
//        }
//        if (statusesList.isEmpty()) {
//            statusesList.add(Status(1,4,"Efficiency", " Cylinder #4","","Knocking Identified - Ignition Timing (deg): 0.7",0,0,1,"06:53:12 UTC  01/04/2020"))
//            statusesList.add(Status(3,2,"Alert", "Cylinder #2","Compression pressure fault","* comp. press: -1.35 std   * Possibly BlowBy - Piston Rings",1,1,2,"01:23:41 UTC  29/03/2020"))
//
//        }
//    }


    private fun initNewRv() {
        status_rv_new_notification.apply {
            layoutManager = LinearLayoutManager(activity)
            val topSpacingItemDecoration = TopSpacingItemDecoration(10)
            addItemDecoration(topSpacingItemDecoration)
            ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(status_rv_new_notification)
            statusNewRVAdapter = NewStatusAdapter(this@StatusFragment)
            adapter = statusNewRVAdapter
        }
    }

    override fun onItemSelected(position: Int, item: Status) {

////        val status = Status(item.statusId,item.cylinder_num,item.statusMainTitle,item.statusSubTitle,item.statusLessContent,item.statusMoreContent,item.statusKindOfDanger,!item.kindOfAcknowledge,item.timeStampOfstatus)
////        statusesListForRv[position].kindOfAcknowledge = !item.kindOfAcknowledge
//        mStatusRepository.deleteStatus(statusesListForRv[position])
//        //insert for db for archive
//        statusesListForRv.remove(item)
//        statusNewRVAdapter.notifyItemRemoved(position)


//        notifyrv()

//        updateList()
//        initFakeRvList()
//        println(statusesList.get(position).toString())

    }


    override fun onClick(v: View?) {
        when(v!!.id){
            R.id.btn_status_to_archive->{
                v.findNavController().navigate(R.id.action_statusFragment_to_statusArchiveFragment)
            }

            R.id.btn_status_to_dashboard->{
                v.findNavController().navigate(R.id.action_statusFragment_to_dashFragment)
            }
            else->{
                Toast.makeText(this.context,"try again", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private val itemTouchHelperCallback: ItemTouchHelper.SimpleCallback =
        object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT or ItemTouchHelper.LEFT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                viewHolder1: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                deleteStatus(statusesListForRv[viewHolder.adapterPosition])
            }
        }

    private fun deleteStatus(status: Status) {
        statusesListForRv.remove(status)
        //update the api that status acknowlkedged, in the future
            GlobalScope.launch {
                dbk.getStatusDao()?.updateStatusAcknowledge(true,status.statusId)
            }
        statusNewRVAdapter.notifyDataSetChanged()

    }
}